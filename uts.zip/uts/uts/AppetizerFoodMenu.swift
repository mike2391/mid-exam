//
//  AppetizerFoodMenu.swift
//  uts
//
//  Created by prk on 19/11/22.
//

import UIKit

class AppetizerFoodMenu: AppetizerListViewController {

}
