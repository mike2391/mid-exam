//
//  FoodPreview.swift
//  uts
//
//  Created by prk on 19/11/22.
//

import Foundation

public struct foodPreview{
    public let FoodImage: String
    public let FoodPrice: Int
}
